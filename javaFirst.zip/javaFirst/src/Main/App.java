package Main;

public class App {
    public static void main(String[] args) throws Exception {
        new Game(); // 1 instance of the actual game
    }
}
